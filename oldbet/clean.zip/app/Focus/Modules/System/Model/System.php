<?php

namespace App\Focus\Modules\System\Model;

use Illuminate\Database\Eloquent\Model;

class System extends Model
{
    //
}
