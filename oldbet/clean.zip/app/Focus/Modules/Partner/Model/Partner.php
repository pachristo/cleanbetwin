<?php

namespace App\Focus\Modules\Partner\Model;

use Illuminate\Database\Eloquent\Model;

class Partner extends Model
{
    //
}
