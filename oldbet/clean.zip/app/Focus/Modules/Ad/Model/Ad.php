<?php

namespace App\Focus\Modules\Ad\Model;

use Illuminate\Database\Eloquent\Model;

class Ad extends Model
{
    //eeehjhj
}
