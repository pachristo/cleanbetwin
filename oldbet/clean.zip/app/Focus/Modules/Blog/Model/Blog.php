<?php

namespace App\Focus\Modules\Blog\Model;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    //
}
