

       
                <div class="row">
                    <div class="col-sm-12 text-center">
                        <h2><strong>FREE TIPS</strong></h2>
                    </div>
                    <div class="col-sm-3 col-6 col-xs-6">
                        <a href="{{route('/1_5_goals')}}">
                            <div class="category_box">
                                <h4>1.5 Goals</h4>
                            </div>
                        </a>
                    </div>

                    <div class="col-sm-3 col-6 col-xs-6">
                        <a href="{{route('/2_5_goals')}}">
                            <div class="category_box">
                                <h4>2.5 Goals</h4>
                            </div>
                        </a>
                    </div>

                    <div class="col-sm-3 col-6 col-xs-6">
                        <a href="{{route('/double_chance')}}">
                            <div class="category_box">
                                <h4>Double Chance</h4>
                            </div>
                        </a>
                    </div>

                    <div class="col-sm-3 col-6 col-xs-6">
                        <a href="{{route('/win_either_half')}}">
                            <div class="category_box">
                                <h4>Win Either Half</h4>
                            </div>
                        </a>
                    </div>

                    <div class="col-sm-3 col-6 col-xs-6">
                        <a href="{{route('/gg_btts')}}">
                            <div class="category_box">
                                <h4>GG/BTTS</h4>
                            </div>
                        </a>
                    </div>

                    <div class="col-sm-3 col-6  col-xs-6">
                        <a href="{{route('/single_bets')}}">
                            <div class="category_box">
                                <h4>Single Bets</h4>
                            </div>
                        </a>
                    </div>

                    <div class="col-sm-3  col-6  col-xs-6">
                        <a href="{{route('/draw_no_bet')}}">
                            <div class="category_box">
                                <h4>Draw No Bet</h4>
                            </div>
                        </a>
                    </div>

                    {{-- <div class="col-sm-3  col-xs-6">
                        <a href="{{route('/draws')}}">
                            <div class="category_box">
                                <h4>Draws</h4>
                            </div>
                        </a>
                    </div> --}}
                    <!-- WORK ON THIS -->
                    <div class="col-sm-3 col-6 col-xs-6">
                        <a href="{{route('/half_time_results')}}">
                            <div class="category_box">
                                <h4>Under 3.5 Goals</h4>
                            </div>
                        </a>
                    </div>

                </div>




       