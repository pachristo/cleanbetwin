<div class="title" style="text-align: center; ">
    <h1 class="" style="
    background: none;
    /* background-color: transparent; */
    padding-top: 7px;
    margin-bottom: 33px;
    border-bottom: 2px solid #62ab38;"><strong><span>{{ $title }}</span></strong>
    </h1>

</div>
