

<div class="row">
    <div class="col-sm-12">
        <h2 class="text-center"> VIP TIPS</h2>
    </div>
    <div class="col-sm-6 col-6 col-xs-6">
        <a href=" {{  route('/sureTwoOdds') }}">
            <div class="category_box">
                <h4>Sure 2 Odds</h4>
            </div>
        </a>
    </div>






    <div class="col-sm-6 col-6 col-xs-6">
        <a href="{{ route('/sureThreeOdds')   }}">
            <div class="category_box">
                <h4>Sure 5 Odds</h4>
            </div>
        </a>
    </div>
    <!-- WORK ON THIS -->
     <div class="col-sm-6 col-6 col-xs-6">
        <a href="{{
            route('/sureFiveOdds')}}">
            <div class="category_box">
                <h4>Sure 10 Odds</h4>
            </div>
        </a>
    </div>
    <div class="col-sm-6  col-6 col-xs-6">
        <a href="{{
            route('/super_investment_tip') }}">
            <div class="category_box">
                <h4>Investemnt</h4>
            </div>
        </a>
    </div>

</div>





