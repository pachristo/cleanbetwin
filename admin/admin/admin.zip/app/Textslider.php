<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Textslider extends Model
{
    //
}
