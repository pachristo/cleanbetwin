<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>CLEANODDS</title>
</head>

<body yahoo="" bgcolor="#ffffff" style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; margin: 0; padding: 0; min-width: 100%;">
<table width="100%" bgcolor="#ffffff" border="0" cellpadding="10" cellspacing="0" style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt; border-collapse: collapse;">
    <tr>
        <td style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
            <!--[if (gte mso 9)|(IE)]>
            <table width="600" align="center" cellpadding="0" cellspacing="0" border="0">
                <tr>
                    <td>
            <![endif]-->
            <table bgcolor="#ffffff" class="content" align="center" cellpadding="0" cellspacing="0" border="0" style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; max-width: 600px; border-collapse: collapse;" width="100%">
                <tr>
                    <td valign="top" mc:edit="headerBrand" id="templateContainerHeader" style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-size: 14px; padding-top: 2.429em; padding-bottom: 0.929em;">

                        <p style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; color: #545454; display: block; font-family: Helvetica; font-size: 16px; line-height: 1.500em; font-style: normal; font-weight: normal; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 15px; margin-left: 0; text-align: center; margin: 0; padding: 0;">
                            <img src="{{asset('images/logo.png')}}" style="-ms-interpolation-mode: bicubic; border: 0; line-height: 100%; outline: none; text-decoration: none; height: auto; min-height: 1px; max-width: 150px; display: inline-block;">
                        </p>

                    </td>
                </tr>
                <tr>
                    <td align="center" valign="top" style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
                        <!-- BEGIN BODY // -->
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" id="templateContainer" style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt; border-top: 1px solid #e2e2e2; border-bottom: 1px solid #e2e2e2; border-left: 1px solid #e2e2e2; border-right: 1px solid #e2e2e2; border-radius: 4px 4px 4px 4px; background-clip: padding-box; border-spacing: 0; border-collapse: collapse;">
                            <tr>
                                <td valign="top" class="bodyContent" mc:edit="body_content" style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #505050; font-family: Helvetica; font-size: 14px; line-height: 150%; padding-top: 3.143em; padding-right: 3.5em; padding-left: 3.5em; padding-bottom: 0.714em; text-align: left;" align="left">
                                    <h4 style="margin-top: 0; margin-right: 0; margin-bottom: 15px; margin-left: 0; display: block; margin: 0; padding: 0; color: #202020; font-family: Helvetica; font-size: 26px; font-style: normal; font-weight: bold; line-height: 125%; letter-spacing: normal; text-align: left;"><span style="color:#008000"><span style="font-size:16px">Hello {{$name}},</span></span></h4>
                                    {!! $content !!}
                                </td>
                            </tr>
                        </table>
                        <!-- // END BODY -->
                    </td>
                </tr>
                <tr>
                    <td align="center" valign="top" id="bodyCellFooter" class="unSubContent" style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt; margin: 0; padding: 0; padding-top: 39px; padding-bottom: 15px; width: 100%;" width="100%">
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" id="templateContainerFooter" style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt; border-collapse: collapse;">
                            <tr>
                                <td valign="top" width="100%" mc:edit="footer_unsubscribe" style="-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
                                    <h6 style="display: block; font-family: Helvetica; font-style: normal; font-weight: normal; letter-spacing: normal; margin-right: 0; margin-left: 0; color: #a1a1a1; font-size: 12px; line-height: 1.5em; margin-bottom: 0; text-align: center; margin-top: 9px;">Cleanodds Services <br>
                            
                                        <strong>Email:</strong> info@Cleanodds.com
                                    </h6>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

            </table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>
</table>
<style type="text/css">
    @media only screen and (max-width: 550px), screen and (max-device-width: 550px) {
        body[yahoo] .hide {
            display: none!important;
        }

        body[yahoo] .buttonwrapper {
            background-color: transparent!important;
        }

        body[yahoo] .button {
            padding: 0px!important;
        }

        body[yahoo] .button a {
            background-color: #e05443;
            padding: 15px 15px 13px!important;
        }

        body[yahoo] .unsubscribe {
            display: block;
            margin-top: 20px;
            padding: 10px 50px;
            background: #2f3942;
            border-radius: 5px;
            text-decoration: none!important;
            font-weight: bold;
        }
    }
    @media only screen and (max-width: 480px) {
        h1 {
            font-size: 34px !important;
        }

        h2 {
            font-size: 30px !important;
        }

        h3 {
            font-size: 24px !important;
        }

        h4 {
            font-size: 18px !important;
        }

        h5 {
            font-size: 16px !important;
        }

        h6 {
            font-size: 14px !important;
        }

        p {
            font-size: 18px !important;
        }

        .bodyContent {
            padding: 6% 5% 1% 6% !important;
        }

        .bodyContent img {
            max-width: 100% !important;
        }

        .bodyContentImage {
            padding: 3% 6% 3% 6% !important;
        }

        .bodyContentImage img {
            max-width: 100% !important;
        }

        .bodyContentImage h4 {
            font-size: 16px !important;
        }

        .bodyContentImage h5 {
            font-size: 15px !important;
            margin-top: 0;
        }
    }
</style>
</body>
</html>
